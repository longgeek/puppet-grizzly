require 'puppet/application/indirection_base'

class Puppet::Application::Instrumentation_listener < Puppet::Application::IndirectionBase
end
