# The base class for AST nodes representing top level things:
# hostclasses, definitions, and nodes.
class Puppet::Parser::AST::TopLevelConstruct < Puppet::Parser::AST
end
