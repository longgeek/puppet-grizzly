require 'puppet/file_serving/content'

# A stub class, so our constants work.
class Puppet::Indirector::FileContent # :nodoc:
end
