Files with extension p.gz are compressed pickle files containing serialized
mocks used during unit testing
